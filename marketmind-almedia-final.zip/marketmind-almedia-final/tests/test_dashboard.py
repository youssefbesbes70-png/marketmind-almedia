from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

import dashboard
from graph import build_graph
from monitoring.detector import detect_payment_incidents
from simulator import generate_data
from visualization import metric_graph_figure


def test_metric_graph_draws_real_graph_and_selected_path():
    graph = build_graph()
    path = ["payment_success_rate", "successful_payments", "orders", "revenue"]
    figure = metric_graph_figure(graph, path).to_plotly_json()
    assert set(figure["data"][-1]["ids"]) == set(graph)
    assert {(trace["meta"]["source"], trace["meta"]["target"])
            for trace in figure["data"] if "meta" in trace} == set(graph.edges)


def test_streamlit_dashboard_opens_without_an_api_key(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    entrypoint = Path(__file__).resolve().parents[1] / "dashboard.py"
    app = AppTest.from_file(entrypoint, default_timeout=20).run()
    assert not app.exception
    assert any("MarketMind" in item.value for item in app.title)
    assert any("Revenue by hour" in item.proto.spec for item in app.get("plotly_chart"))


def test_two_distinct_incidents_and_overnight_pattern():
    data = generate_data(seed=42)
    found = detect_payment_incidents(data)
    assert {(item["country"], item["device"], item["hours_affected"])
            for item in found} == {("FR", "iOS", 3), ("DE", "Android", 5)}
    overnight = data.loc[data.scenario.eq("expected_overnight")]
    assert detect_payment_incidents(overnight) == []


@pytest.mark.parametrize(
    ("action_id", "expected_scenario"),
    [("retry_failed_payments", "approved_demo_retry"),
     ("switch_backup_route", "approved_demo_backup_route")],
)
def test_approved_action_changes_only_matching_simulated_hours(monkeypatch, action_id, expected_scenario):
    data = generate_data(seed=42)
    report = next(item for item in detect_payment_incidents(data) if item["country"] == "FR")
    monkeypatch.setattr(dashboard.st, "session_state", dashboard.st.session_state)
    dashboard.st.session_state.market_data = data.copy()
    ok, message = dashboard._repair_simulated_incident(report, action_id)
    assert ok, message
    changed = dashboard.st.session_state.market_data
    assert (changed.scenario == expected_scenario).sum() == report["hours_affected"]
    assert len(detect_payment_incidents(changed)) == 1
    assert "no matching" in message
