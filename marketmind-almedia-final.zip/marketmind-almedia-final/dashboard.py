"""Live replay dashboard for MarketMind's simulated marketplace."""

from datetime import datetime, timedelta
from os import getenv
from pathlib import Path
import time

import pandas as pd
import plotly.express as px
import streamlit as st
from streamlit.errors import StreamlitSecretNotFoundError

from graph import build_graph
from monitoring.ai_explainer import ANALYSIS_SECTIONS, analyze_incident
from monitoring.detector import detect_payment_incidents
from monitoring.investigator import investigate_incident
from simulator import generate_data
from visualization import metric_graph_figure


ACTION_LABELS = {
    "retry_failed_payments": "Retry failed payments (simulated)",
    "switch_backup_route": "Switch to backup payment route (simulated)",
}


def _api_key():
    key = getenv("ANTHROPIC_API_KEY", "").strip()
    if not key:
        try:
            key = st.secrets.get("ANTHROPIC_API_KEY", "")
        except StreamlitSecretNotFoundError:
            key = ""
    return key.strip() if isinstance(key, str) else ""


def _init_session():
    if "market_data" not in st.session_state:
        data = generate_data(seed=42)
        st.session_state.market_data = data
        st.session_state.graph = build_graph()
        st.session_state.sim_clock = data["timestamp"].max().replace(hour=9)
        st.session_state.last_tick = time.monotonic()
        st.session_state.analyses = {}
        st.session_state.resolutions = {}


def _repair_simulated_incident(report, action_id):
    """Apply a fixed, allowlisted change to demo rows, then verify detection clears."""
    data = st.session_state.market_data.copy()
    start = pd.Timestamp(report["start_timestamp"])
    end = pd.Timestamp(report["end_timestamp"])
    mask = (
        data["country"].eq(report["country"])
        & data["device"].eq(report["device"])
        & data["timestamp"].between(start, end)
        & data["scenario"].eq("payment_failure")
    )
    if not mask.any():
        return False, "No simulated failure rows matched this incident."
    attempts = data.loc[mask, "checkout_attempts"]
    baseline = float(report["baseline_payment_success_rate"])
    expected_success = (attempts * baseline).round().astype(int)
    if action_id == "retry_failed_payments":
        success = (data.loc[mask, "successful_payments"] +
                   ((expected_success - data.loc[mask, "successful_payments"]) * 0.80).round()).astype(int)
        new_scenario = "approved_demo_retry"
    elif action_id == "switch_backup_route":
        success = expected_success
        new_scenario = "approved_demo_backup_route"
    else:
        return False, "The requested action is not on the approved demo action list."
    data.loc[mask, "successful_payments"] = success
    data.loc[mask, "orders"] = success
    data.loc[mask, "payment_success_rate"] = success.div(attempts.where(attempts > 0, 1))
    data.loc[mask, "revenue"] = success * data.loc[mask, "average_order_value"]
    data.loc[mask, "scenario"] = new_scenario
    remaining = detect_payment_incidents(data)
    same_incident = any(
        item["country"] == report["country"] and item["device"] == report["device"]
        and pd.Timestamp(item["start_timestamp"]) <= end
        and pd.Timestamp(item["end_timestamp"]) >= start
        for item in remaining
    )
    if same_incident:
        return False, "The detector still sees this incident; the simulated change was not accepted."
    st.session_state.market_data = data
    return True, "Detector re-scan found no matching payment incident in the repaired hours."


def _get_reports(data, clock):
    graph = st.session_state.graph
    # Timestamps mark the beginning of an hour, so wait until that hour has ended.
    incidents = detect_payment_incidents(data.loc[data.timestamp < clock - timedelta(hours=1)])
    reports = [investigate_incident(item, graph) for item in incidents]
    window_start = clock - timedelta(hours=24)
    recent = [r for r in reports if pd.Timestamp(r["end_timestamp"]) >= window_start]
    return [r for r in recent if r["incident_id"] not in st.session_state.resolutions]


def _render_kpis(window):
    visitors = int(window.visitors.sum())
    attempts = int(window.checkout_attempts.sum())
    successful = int(window.successful_payments.sum())
    orders = int(window.orders.sum())
    revenue = float(window.revenue.sum())
    rate = successful / attempts if attempts else 0.0
    columns = st.columns(5)
    for column, label, value in zip(columns,
        ("Visitors", "Checkout attempts", "Payment success", "Orders", "Revenue"),
        (f"{visitors:,}", f"{attempts:,}", f"{rate:.1%}", f"{orders:,}", f"€{revenue:,.2f}")):
        column.metric(label, value)


def _render_ai_and_approval(report, graph):
    incident_id = report["incident_id"]
    analyses = st.session_state.analyses
    with st.container(border=True):
        st.subheader("Claude investigation and proposed action")
        st.caption("Claude analyzes this simulated incident. Approval changes only in-memory demo data; it does not operate a real payment system.")
        if incident_id not in analyses:
            if st.button("Analyze incident with Claude", key=f"analyze_{incident_id}", type="primary"):
                key = _api_key()
                if not key:
                    st.warning("Set ANTHROPIC_API_KEY in PowerShell or Streamlit secrets first.")
                else:
                    with st.spinner("Claude is analyzing the evidence…"):
                        try:
                            analyses[incident_id] = analyze_incident(report, graph, api_key=key)
                        except (RuntimeError, ValueError) as error:
                            st.error(str(error))
        analysis = analyses.get(incident_id)
        if analysis:
            for key, title in ANALYSIS_SECTIONS:
                st.markdown(f"**{title}**  \n{analysis[key]}")
            action_id = analysis["action_id"]
            if action_id not in ACTION_LABELS:
                st.warning("Claude did not choose an available safe demo action, so approval is disabled.")
            else:
                st.info(f"Proposed: **{ACTION_LABELS[action_id]}** · confidence {analysis['confidence']:.0%}\n\n{analysis['action_rationale']}")
                confirmation = st.checkbox("I approve changing the simulated figures for this incident", key=f"approve_{incident_id}")
                if st.button("Apply approved simulated action", key=f"apply_{incident_id}", disabled=not confirmation):
                    ok, message = _repair_simulated_incident(report, action_id)
                    if ok:
                        st.session_state.resolutions[incident_id] = {
                            "action": action_id, "message": message, "time": datetime.now().isoformat(timespec="minutes")
                        }
                        st.success(f"Simulated action applied and verified. {message}")
                        st.rerun()
                    else:
                        st.error(message)


def _render_dashboard():
    now = time.monotonic()
    if now - st.session_state.last_tick >= 5:
        data = st.session_state.market_data
        maximum = data.timestamp.max()
        st.session_state.sim_clock = min(st.session_state.sim_clock + timedelta(hours=1), maximum)
        st.session_state.last_tick = now

    clock = st.session_state.sim_clock
    all_data = st.session_state.market_data
    visible = all_data.loc[all_data.timestamp <= clock]
    window = visible.loc[visible.timestamp > clock - timedelta(hours=24)].copy()
    st.title("MarketMind")
    st.caption(f"24-hour simulated marketplace report · replay time: {clock:%d %b %Y, %H:%M} Europe/Berlin · refreshes every 5 seconds")
    _render_kpis(window)
    chart_data = window.groupby("timestamp", as_index=False).agg(revenue=("revenue", "sum"), visitors=("visitors", "sum"))
    chart = px.line(chart_data, x="timestamp", y="revenue", markers=True, title="Revenue by hour · simulated EUR")
    chart.update_layout(height=290, margin=dict(l=10, r=10, t=50, b=10), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
    st.plotly_chart(chart, use_container_width=True)

    reports = _get_reports(all_data, clock)
    st.header(f"Incidents in the last 24 simulated hours · {len(reports)}")
    if not reports:
        st.success("No unresolved incidents are active in this 24-hour window.")
    for report in reports:
        with st.expander(f"{report['country']} / {report['device']} · {report['hours_affected']} hours · {report['drop_percentage_points']:.1f} pp drop", expanded=True):
            st.write(f"**Time:** {report['start_timestamp']} to {report['end_timestamp']} (Europe/Berlin)")
            st.write(report["explanation"])
            st.write(f"Evidence: {report['successful_payments']:,} payments from {report['checkout_attempts']:,} checkout attempts; €{report['revenue_eur']:,.2f} revenue during affected hours.")
            _render_ai_and_approval(report, st.session_state.graph)

    with st.expander("Business metric graph", expanded=True):
        st.caption("Orange highlights the selected incident's metric path. This graph shows possible metric relationships, not proof of an operational cause.")
        if reports:
            selected_report_id = st.selectbox(
                "Highlight an incident path", [item["incident_id"] for item in reports],
                format_func=lambda identifier: next(
                    f"{item['country']} / {item['device']} · {item['start_timestamp']}"
                    for item in reports if item["incident_id"] == identifier
                ), key="graph_incident",
            )
            selected_path = next(item["metric_path"] for item in reports if item["incident_id"] == selected_report_id)
        else:
            selected_path = ()
        st.plotly_chart(metric_graph_figure(st.session_state.graph, selected_path), use_container_width=True, config={"displayModeBar": False})
    if st.session_state.resolutions:
        with st.expander("Approved demo actions"):
            for incident_id, result in st.session_state.resolutions.items():
                st.write(f"{incident_id}: {ACTION_LABELS[result['action']]} — verified at {result['time']}. {result['message']}")


def main():
    st.set_page_config(page_title="MarketMind · 24-hour report", layout="wide")
    st.html(Path(__file__).with_name("dashboard.css"))
    _init_session()
    # Streamlit reruns this section every five seconds, advancing the offline replay clock.
    st.fragment(run_every="5s")(_render_dashboard)()


if __name__ == "__main__":
    main()
